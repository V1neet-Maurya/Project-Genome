// Sample test file for code-analysis testing

function add(a, b) {
  return a + b;
}

console.log(add(2, 3));
